import{f as y}from"./index-DsA5fDtS.js";const s="leazr-sourcing-badge";async function b(){const t=(await chrome.storage.local.get("sourcing_context")).sourcing_context;return!t||new Date(t.expires_at).getTime()<Date.now()?null:t}function f(e,t){var m;const i=document.getElementById(s);i&&i.remove();const o=document.createElement("div");o.id=s,o.style.cssText=`
    position: fixed;
    bottom: 20px;
    right: 20px;
    z-index: 2147483647;
    width: 320px;
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.18);
    padding: 16px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    color: #1e293b;
    font-size: 13px;
    line-height: 1.5;
    animation: leazr-slide-in 0.3s ease-out;
  `;const d=document.createElement("style");d.textContent=`
    @keyframes leazr-slide-in {
      from { transform: translateY(20px); opacity: 0; }
      to   { transform: translateY(0);    opacity: 1; }
    }
    #${s} button { font-family: inherit; }
  `,document.head.appendChild(d);const x=(e.price_cents/100).toFixed(2).replace(".",","),u=e.delivery_days_min||e.delivery_days_max?`Livré en ${e.delivery_days_min??"?"}${e.delivery_days_max&&e.delivery_days_max!==e.delivery_days_min?`-${e.delivery_days_max}`:""} j`:"",p=e.stock_status==="in_stock"?"✅ En stock":e.stock_status==="limited"?"⚠️ Stock limité":e.stock_status==="out_of_stock"?"❌ Rupture":"";o.innerHTML=`
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
      <span style="font-size:18px">🦎</span>
      <strong style="font-size:13px;color:#3730a3">Leazr Sourcing</strong>
      <button id="leazr-close-badge" style="margin-left:auto;background:none;border:none;cursor:pointer;color:#64748b;font-size:16px">✕</button>
    </div>
    <div style="font-weight:600;margin-bottom:6px;line-height:1.3">${c(e.title.length>80?e.title.slice(0,80)+"…":e.title)}</div>
    <div style="color:#475569;margin-bottom:10px">
      <span style="font-weight:700;font-size:15px;color:#1e293b">${x} €</span>
      ${u?` · ${u}`:""}
      ${p?` · ${p}`:""}
    </div>
    ${t?`<div style="background:#eef2ff;border:1px solid #c7d2fe;border-radius:6px;padding:8px 10px;margin-bottom:10px;font-size:12px;color:#3730a3">
             <div style="font-weight:600;margin-bottom:2px">Commande en cours</div>
             <div>${c(t.label)}${t.order_label?` · ${c(t.order_label)}`:""}</div>
           </div>`:`<div style="background:#fef3c7;border:1px solid #fde68a;border-radius:6px;padding:8px 10px;margin-bottom:10px;font-size:12px;color:#92400e">
             Aucune commande sélectionnée dans Leazr. Ouvrez la popup pour choisir un contexte.
           </div>`}
    <button id="leazr-submit-btn" ${t?"":"disabled"} style="
      width:100%;padding:10px;
      background:${t?"#4f46e5":"#94a3b8"};
      color:white;border:none;border-radius:8px;
      font-weight:600;font-size:13px;
      cursor:${t?"pointer":"not-allowed"};
    ">
      ${t?"+ Ajouter à la commande":"Sélectionnez une commande"}
    </button>
    <div id="leazr-feedback" style="margin-top:8px;font-size:12px;text-align:center;min-height:16px"></div>
  `,document.body.appendChild(o),(m=document.getElementById("leazr-close-badge"))==null||m.addEventListener("click",()=>o.remove());const r=document.getElementById("leazr-submit-btn");r==null||r.addEventListener("click",async()=>{if(!t)return;r.disabled=!0,r.textContent="Envoi…";const a=document.getElementById("leazr-feedback");try{const n=await chrome.runtime.sendMessage({type:"submit_offer",offer:e,context:t});if(n!=null&&n.success)a&&(a.textContent=n.needs_validation?"✅ Proposée (en attente de validation admin)":"✅ Ajoutée à Leazr",a.style.color="#059669"),r.textContent="Envoyée ✓",setTimeout(()=>o.remove(),2500);else throw new Error((n==null?void 0:n.error)??"Erreur inconnue")}catch(n){a&&(a.textContent=`❌ ${n.message}`,a.style.color="#dc2626"),r.disabled=!1,r.textContent="Réessayer"}})}function c(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}async function l(){const e=new URL(window.location.href);console.log("[Leazr Sourcing] Content script actif sur",e.href);const t=y(e);if(!t){console.log("[Leazr Sourcing] Aucun adapter pour ce host :",e.hostname);return}if(console.log(`[Leazr Sourcing] Adapter "${t.name}" sélectionné`),!t.isProductPage(document,e)){console.log("[Leazr Sourcing] Pas une page produit selon l'adapter");return}console.log("[Leazr Sourcing] Page produit détectée, extraction en cours…");const i=t.extract(document,e);if(!i.ok){console.warn(`[Leazr Sourcing] Échec extraction (${t.name}):`,i.reason);return}const o=await b();console.log("[Leazr Sourcing] Contexte actuel :",o??"aucun"),f(i.offer,o),console.log("[Leazr Sourcing] Badge affiché ✅")}setTimeout(()=>{l().catch(e=>console.error("[Leazr Sourcing] Erreur run():",e))},1e3);setTimeout(()=>{document.getElementById(s)||(console.log("[Leazr Sourcing] Retry après hydratation tardive…"),l().catch(e=>console.error("[Leazr Sourcing] Erreur run() retry:",e)))},3500);let g=location.href;new MutationObserver(()=>{location.href!==g&&(g=location.href,setTimeout(l,1200))}).observe(document,{childList:!0,subtree:!0});
//# sourceMappingURL=index.ts-rzM8nlJO.js.map
